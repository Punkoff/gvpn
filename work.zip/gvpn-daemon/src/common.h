#include <stdio.h>
#include <stdlib.h>
#include <syslog.h>
#include <errno.h>

void error(char* str);
