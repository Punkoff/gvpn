#include "common.h"

void error(char* str){
	printf(str);
	exit(EXIT_FAILURE);
}
