#include <sys/poll.h>
#include <sys/types.h> 
#include <fcntl.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void CfgLoad();
void CfgSave();
