/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * main.c
 * Copyright (C) John Pankov 2008 <pankov@adsl.by>
 * 
 * main.c is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * main.c is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include "comm.h"
int main()
{
	while (1) {
		CommServerInit("/home/john/foobar");
		CommServerAccept();
		printf("Client connected\n");
		char buf[256];
		strcpy(buf,"Hello client");
		while (strcmp(buf,"")!=0) {
			CommServerSendString (buf);
			CommServerReceiveString (buf);
			printf("Received:%s\n",buf);
		}
		CommServerClose();
		printf("Client disconnected\n");		
	}
}
